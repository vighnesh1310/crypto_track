// pages/Portfolio.jsx
import React, { useEffect, useState } from 'react';
import axiosInstance from '../utils/axiosInstance';
import { fetchMarketData } from '../utils/cryptoAPI';
import { Sidebar } from '../components/Sidebar';
import { useSidebar } from '../context/SidebarContext';
import { Pie, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
} from 'chart.js';

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement
);

export function Portfolio() {
  const [holdings, setHoldings] = useState([]);
  const [marketData, setMarketData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { isOpen } = useSidebar();

  useEffect(() => {
    const fetchPortfolio = async () => {
      try {
        const res = await axiosInstance.get('/portfolio');
        const userHoldings = Array.isArray(res.data.holdings) ? res.data.holdings : [];
        setHoldings(userHoldings);

        const coinIds = userHoldings.map((h) => h.coinId).join(',');
        const marketRes = await fetchMarketData('usd', 100);
        const filteredData = marketRes.filter((coin) => coinIds.includes(coin.id));
        setMarketData(filteredData);
      } catch (err) {
        console.error('Error fetching portfolio:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPortfolio();
  }, []);

  const getQuantity = (coinId) => {
    const holding = holdings.find((h) => h.coinId === coinId);
    return holding ? holding.quantity || 0 : 0;
  };

  const getTotalValue = () => {
    return marketData.reduce((acc, coin) => {
      const quantity = getQuantity(coin.id);
      return acc + quantity * coin.current_price;
    }, 0);
  };

  const pieData = {
    labels: marketData.map((coin) => coin.name),
    datasets: [
      {
        label: 'Value',
        data: marketData.map((coin) => getQuantity(coin.id) * coin.current_price),
        backgroundColor: [
          '#6366f1', '#10b981', '#f59e0b', '#ef4444',
          '#8b5cf6', '#3b82f6', '#ec4899', '#14b8a6',
        ],
        borderWidth: 1,
      },
    ],
  };

  const lineData = {
    labels: marketData.map((coin) => coin.name),
    datasets: [
      {
        label: 'Holding Value',
        data: marketData.map((coin) => getQuantity(coin.id) * coin.current_price),
        borderColor: '#14b8a6',
        backgroundColor: 'rgba(20, 184, 166, 0.2)',
        tension: 0.4,
      },
    ],
  };

  if (isLoading) {
    return <div className="text-center p-6 text-gray-600 dark:text-gray-300">Loading portfolio...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white flex">
      <Sidebar />
      <div className={`flex-1 px-4 sm:px-8 py-8 transition-all duration-300 ${isOpen ? 'ml-64' : 'ml-16'}`}>
        <h2 className="text-3xl font-bold mb-4">📊 My Portfolio</h2>
        <div className="text-lg font-semibold mb-6 text-green-600 dark:text-green-400">
          Total Value: ${getTotalValue().toLocaleString(undefined, { maximumFractionDigits: 2 })}
        </div>

        {/* Coin List */}
        {marketData.length === 0 ? (
          <div className="text-gray-500 dark:text-gray-400">No coins in your portfolio.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {marketData.map((coin) => {
              const quantity = getQuantity(coin.id);
              return (
                <div
                  key={coin.id}
                  className="flex justify-between items-center bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md"
                >
                  <div className="flex items-center gap-3">
                    <img src={coin.image} alt={coin.name} className="w-8 h-8" />
                    <div>
                      <div className="font-semibold">{coin.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">Qty: {quantity}</div>
                    </div>
                  </div>
                  <div className="text-right text-sm">
                    <div className="text-gray-800 dark:text-gray-200">
                      ${Number(quantity * coin.current_price).toFixed(2)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Charts Section */}
        {marketData.length > 0 && (
          <div className="grid md:grid-cols-2 gap-6 mt-10">
            <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md">
              <h3 className="text-lg font-semibold mb-3">💹 Portfolio Breakdown</h3>
              <Pie data={pieData} />
            </div>
            <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md">
              <h3 className="text-lg font-semibold mb-3">📈 Holdings Chart</h3>
              <Line data={lineData} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
