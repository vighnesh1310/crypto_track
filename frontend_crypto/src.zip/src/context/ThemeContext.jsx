import React, { createContext, useContext, useEffect, useState } from 'react';
import { useUser } from './UserContext';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }) => {
  const { user } = useUser();
  const darkModeFromSettings = user?.settings?.darkMode;

  const [theme, setTheme] = useState('light');

  useEffect(() => {
    if (darkModeFromSettings) {
      document.documentElement.classList.add('dark');
      setTheme('dark');
    } else {
      document.documentElement.classList.remove('dark');
      setTheme('light');
    }
  }, [darkModeFromSettings]);

  return (
    <ThemeContext.Provider value={{ theme }}>
      {children}
    </ThemeContext.Provider>
  );
};
