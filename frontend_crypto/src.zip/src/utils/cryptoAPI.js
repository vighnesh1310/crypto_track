import axios from 'axios';

const BASE_URL = 'https://api.coingecko.com/api/v3';
const API_KEY = process.env.REACT_APP_COINGECKO_API_KEY || ''; // if using React

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    'x-cg-pro-api-key': API_KEY, // ✅ CoinGecko Pro header
  },
});

// 📊 Fetch market data
export const fetchMarketData = async (vs_currency = 'usd', per_page = 10, sparkline = false) => {
  const response = await axiosInstance.get('/coins/markets', {
    params: {
      vs_currency,
      order: 'market_cap_desc',
      per_page,
      page: 1,
      sparkline,
      price_change_percentage: '24h',
    }
  });
  return response.data;
};

// 🚀 Trending coins
export const fetchTrendingCoins = async () => {
  const response = await axiosInstance.get('/search/trending');
  return response.data.coins;
};

// 📈 Coin price history
export const fetchCoinHistory = async (coinId = 'bitcoin', days = 7, currency = 'usd') => {
  const res = await axiosInstance.get(`/coins/${coinId}/market_chart`, {
    params: {
      vs_currency: currency,
      days,
    }
  });
  return res.data.prices;
};

// 🧾 Coin full details
export const fetchCoinDetails = async (coinId) => {
  const res = await axiosInstance.get(`/coins/${coinId}`, {
    params: {
      localization: false,
      tickers: false,
      market_data: true,
      community_data: false,
      developer_data: false,
      sparkline: false,
    }
  });
  return res.data;
};
