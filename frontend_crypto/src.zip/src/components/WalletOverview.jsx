// WalletOverview.jsx
import React, { useEffect, useState, useRef } from 'react';
import { fetchMarketData } from '../utils/cryptoAPI';
import { fetchUserHoldings } from '../utils/portfolioAPI';
import { useReactToPrint } from 'react-to-print';

export function WalletOverview() {
  const [coins, setCoins] = useState([]);
  const [holdings, setHoldings] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const componentRef = useRef();

  useEffect(() => {
    const fetchWalletData = async () => {
      try {
        const [marketData, userHoldings] = await Promise.all([
          fetchMarketData('usd', 100),
          fetchUserHoldings(),
        ]);
        setCoins(marketData);
        setHoldings(userHoldings);
      } catch (err) {
        setError('Failed to load wallet data.');
      } finally {
        setLoading(false);
      }
    };

    fetchWalletData();
  }, []);

  const totalValue = coins.reduce((acc, coin) => {
    const qty = holdings[coin.id] || 0;
    return acc + qty * coin.current_price;
  }, 0);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'MyCryptoWallet',
  });

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow w-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-2xl font-bold flex items-center gap-2">💼 My Wallet</h3>
        <button onClick={handlePrint} className="text-sm text-blue-500 hover:underline">
          🧾 Export PDF
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-6 bg-gray-300 dark:bg-gray-700 rounded animate-pulse"></div>
          ))}
        </div>
      ) : error ? (
        <p className="text-red-500">{error}</p>
      ) : (
        <div ref={componentRef}>
          <p className="text-lg font-semibold text-green-600 dark:text-green-400 mb-4">
            Total Value: ${totalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {coins
              .filter((coin) => holdings[coin.id])
              .sort((a, b) => (holdings[b.id] * b.current_price) - (holdings[a.id] * a.current_price))
              .map((coin) => {
                const qty = holdings[coin.id];
                const value = qty * coin.current_price;
                return (
                  <div
                    key={coin.id}
                    className="bg-gray-50 dark:bg-gray-900 border dark:border-gray-700 rounded-lg p-4 flex flex-col justify-between shadow-sm"
                  >
                    <div className="flex items-center gap-3">
                      <img src={coin.image} alt={coin.name} className="w-8 h-8" />
                      <div>
                        <h4 className="font-semibold">{coin.name}</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Qty: {qty}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 text-right">
                      <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                        ${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                      </p>
                      <p
                        className={
                          coin.price_change_percentage_24h >= 0
                            ? 'text-xs text-green-500'
                            : 'text-xs text-red-500'
                        }
                      >
                        {coin.price_change_percentage_24h.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
}
